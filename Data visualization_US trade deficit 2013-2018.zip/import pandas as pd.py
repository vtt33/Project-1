import pandas as pd
import matplotlib.pyplot as plt

# Load export and import data from CSV files
exports_data = pd.read_csv(r"C:\Users\stona\OneDrive\Desktop\NBDIME\Project-1\Resources\US_export_import_data_2013-2018.csv")
imports_data = pd.read_csv(r"C:\Users\stona\OneDrive\Desktop\NBDIME\Project-1\Resources\US_export_import_data_2013-2018.csv")

# Ensure the columns have no leading/trailing spaces
exports_data.columns = exports_data.columns.str.strip()
imports_data.columns = imports_data.columns.str.strip()

# Convert the 'Year' column to numeric
exports_data['Year'] = pd.to_numeric(exports_data['Year'], errors='coerce')
imports_data['Year'] = pd.to_numeric(imports_data['Year'], errors='coerce')

# Drop rows with NaN values in 'Year'
exports_data = exports_data.dropna(subset=['Year'])
imports_data = imports_data.dropna(subset=['Year'])

# Filter the data for the years 2013 through 2018
exports_data = exports_data[(exports_data['Year'] >= 2013) & (exports_data['Year'] <= 2018)]
imports_data = imports_data[(imports_data['Year'] >= 2013) & (imports_data['Year'] <= 2018)]

# Group by year and sum the values
grouped_exports = exports_data.groupby('Year')['Exports'].sum().reset_index()
grouped_imports = imports_data.groupby('Year')['Imports'].sum().reset_index()

# Merge the exports and imports data on Year
merged_data = pd.merge(grouped_exports, grouped_imports, on='Year')

# Calculate the cumulative values for the stacked area plot
merged_data['Total'] = merged_data['Exports'] + merged_data['Imports']

# Plotting stacked line graph
plt.figure(figsize=(10, 6))
plt.stackplot(merged_data['Year'], merged_data['Exports'], merged_data['Imports'], labels=['Exports', 'Imports'], colors=['b', 'r'])

# Customize the plot
plt.title('Total United States Exports and Imports (2013-2018)')
plt.xlabel('Year')
plt.ylabel('Total Value (in billions)')
plt.legend(loc='upper left')
plt.xticks(range(2013, 2019))
plt.grid(True)
plt.savefig('us_exports_imports_2013_2018.png')
plt.show()

# Export the graph to an Excel file 

export_graph.to_excel ("US_export_import_data_2013-2018")




