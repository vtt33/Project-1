import pandas as pd
import matplotlib.pyplot as plt

# Load export and import data from CSV files
exports_data = pd.read_csv(r"C:\Users\stona\OneDrive\Desktop\Project-1\Resources\US_export_data..csv")
imports_data = pd.read_csv(r"C:\Users\stona\OneDrive\Desktop\Project-1\Resources\US_import_data.csv")

# Print column names to verify
print("Export Data Columns:", exports_data.columns)
print("Import Data Columns:", imports_data.columns)

# Ensure the columns have no leading/trailing spaces
exports_data.columns = exports_data.columns.str.strip()
imports_data.columns = imports_data.columns.str.strip()

# Ensure 'Year' and 'Country' columns are present
if 'Year' not in exports_data.columns or 'Country' not in exports_data.columns:
    raise KeyError("Columns 'Year' and/or 'Country' not found in exports_data")
if 'Year' not in imports_data.columns or 'Country' not in imports_data.columns:
    raise KeyError("Columns 'Year' and/or 'Country' not found in imports_data")

# Ensure 'Year' column is numeric
exports_data['Year'] = pd.to_numeric(exports_data['Year'], errors='coerce')
imports_data['Year'] = pd.to_numeric(imports_data['Year'], errors='coerce')

# Drop rows with NaN values in 'Year'
exports_data = exports_data.dropna(subset=['Year'])
imports_data = imports_data.dropna(subset=['Year'])

# Filter the data for the years 2013 through 2018
exports_data = exports_data[(exports_data['Year'] >= 2013) & (exports_data['Year'] <= 2018)]
imports_data = imports_data[(imports_data['Year'] >= 2013) & (imports_data['Year'] <= 2018)]

# Group by year and country, then sum the values
grouped_exports = exports_data.groupby(['Year', 'Country'])['Value'].sum().reset_index()
grouped_imports = imports_data.groupby(['Year', 'Country'])['Value'].sum().reset_index()

# Print the grouped data to verify
print("Grouped Exports Data:")
print(grouped_exports.head())
print("\nGrouped Imports Data:")
print(grouped_imports.head())

# Merge the exports and imports data on Year and Country
merged_data = pd.merge(grouped_exports, grouped_imports, on=['Year', 'Country'], suffixes=('_Exports', '_Imports'))

# Plotting Exports and Imports over the years for each country
fig, ax = plt.subplots(figsize=(14, 8))

# Plot Total Exports
for country in merged_data['Country'].unique():
    country_data = merged_data[merged_data['Country'] == country]
    ax.plot(country_data['Year'], country_data['Value_Exports'], label=f'{country} Exports', linestyle='--', marker='o')

# Plot Total Imports
for country in merged_data['Country'].unique():
    country_data = merged_data[merged_data['Country'] == country]
    ax.plot(country_data['Year'], country_data['Value_Imports'], label=f'{country} Imports', linestyle='-', marker='x')

# Customize the plot
ax.set_title('Total United States Exports and Imports per Country (2013-2018)')
ax.set_xlabel('Year')
ax.set_ylabel('Total Value (in billions)')
ax.legend(loc='best', fontsize='small')
plt.xticks(range(2013, 2019))

# Save and show the plot
plt.savefig('us_exports_imports_2013_2018.png')
plt.show()
